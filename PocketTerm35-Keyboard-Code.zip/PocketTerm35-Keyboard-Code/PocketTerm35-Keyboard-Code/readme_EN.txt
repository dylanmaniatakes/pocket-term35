# RP2040 Keyboard Firmware Installation Guide

## (For Raspberry Pi)

### Preparation

1. Copy **PocketTerm35-Keyboard-Code.zip** to the **Desktop** of your Raspberry Pi.
2. Extract the ZIP file.
3. Open the extracted **PocketTerm35-Keyboard-Code** folder.

---

### Installation Steps

#### Step 1. Enter Bootloader Mode

Press and hold the **BOOT** button.

While holding **BOOT**, press and release the **RESET** button.

Release the **BOOT** button.

The **RPI-RP2** USB drive will appear.

---

#### Step 2. Initialize RP2040

Drag **nuke_universal.uf2** onto the **RPI-RP2** drive.

Wait until the **RPI-RP2** drive appears again automatically.

---

#### Step 3. Install CircuitPython

Drag **firmware.uf2** onto the **RPI-RP2** drive.

Wait until the **CIRCUITPY** USB drive appears.

---

#### Step 4. Update Library

Open the **CIRCUITPY** drive.

Drag the **lib** folder from the firmware package into the **CIRCUITPY** drive.

Replace the existing folder if prompted.

---

#### Step 5. Update Application

Drag **code.py** into the **CIRCUITPY** drive.

Replace the existing **code.py** file if prompted.

---

#### Step 6. Restart

Press the **RESET** button once.

The RP2040 will restart.

Verify that the modified **code.py** is running correctly.

---

#### Step 7. Hide the CIRCUITPY Drive (Optional)

If no further code modification is required, drag **boot.py** into the **CIRCUITPY** drive.

Replace the existing **boot.py** file if prompted.

Press **RESET** once.

After restarting, the **CIRCUITPY** drive will be hidden automatically.

---

### Notes

* **nuke_universal.uf2** initializes the RP2040 Flash and removes all existing files.
* **firmware.uf2** installs the CircuitPython firmware.
* The **CIRCUITPY** drive is available only before installing the supplied **boot.py**.
* To modify the firmware again later, simply repeat the installation procedure from **Step 1**.
