# RP2040 键盘固件安装说明

## （适用于 Raspberry Pi）

### 准备工作

1. 将 **PocketTerm35-Keyboard-Code.zip** 复制到 Raspberry Pi **桌面（Desktop）**。
2. 解压压缩包。
3. 打开解压后的 **PocketTerm35-Keyboard-Code** 文件夹。

---

### 安装步骤

#### 第一步：进入 BOOT 模式

按住 **BOOT** 按钮。

保持 **BOOT** 按下的状态，按一下 **RESET** 按钮并立即松开。

最后松开 **BOOT** 按钮。

此时系统会识别出 **RPI-RP2** U盘。

---

#### 第二步：初始化 RP2040

将 **nuke_universal.uf2** 拖放到 **RPI-RP2** U盘。

等待设备自动重新识别为 **RPI-RP2**。

---

#### 第三步：安装 CircuitPython

将 **firmware.uf2** 拖放到 **RPI-RP2** U盘。

等待系统识别出新的 **CIRCUITPY** U盘。

---

#### 第四步：更新库文件

打开 **CIRCUITPY** U盘。

将固件包中的 **lib** 文件夹拖放到 **CIRCUITPY** 中。

如果提示覆盖，请选择**覆盖**。

---

#### 第五步：更新程序

将 **code.py** 拖放到 **CIRCUITPY** 根目录。

如果提示覆盖，请选择**覆盖**。

---

#### 第六步：重启测试

按一下 **RESET** 按钮。

RP2040 将重新启动。

确认修改后的 **code.py** 已正常运行。

---

#### 第七步：隐藏 CIRCUITPY U盘（可选）

如果程序已经确认正常，并且后续无需继续修改程序，请将 **boot.py** 拖放到 **CIRCUITPY** 根目录。

如果提示覆盖，请选择**覆盖**。

再次按一下 **RESET** 按钮。

设备重启后，**CIRCUITPY** U盘将自动隐藏。

---

### 说明

* **nuke_universal.uf2** 用于初始化 RP2040 Flash，并清除已有程序及文件。
* **firmware.uf2** 用于安装 CircuitPython 固件。
* 安装 **boot.py** 前，系统会显示 **CIRCUITPY** U盘，便于修改程序。
* 安装 **boot.py** 后，**CIRCUITPY** U盘将自动隐藏，这是产品的正常设计。
* 如需再次修改程序，只需重新从**第一步**开始操作即可。
